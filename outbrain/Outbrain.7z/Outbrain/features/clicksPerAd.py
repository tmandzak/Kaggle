def clicksPerAd(clicks):
    return pd.DataFrame({'clicks': clicks.groupby(['ad_id'])['clicked'].sum(),
                         'shows': clicks.groupby(['ad_id'])['clicked'].size(),
                         'clicksPerShows': clicks.groupby(['ad_id'])['clicked'].mean()
                        }).reset_index()

def clicksPerAdDay(clicks):
    return pd.DataFrame({'clicksPerShows': clicks.groupby(['ad_id', 'day'])['clicked'].mean()
                        }).reset_index()